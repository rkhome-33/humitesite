# HUMITEK – Site (Next.js + Tailwind)
- Logo: /public/logo_humitek.png
- Modifier le contenu principal dans `pages/index.jsx`
- Déployer sur Vercel (Next.js détecté automatiquement).
